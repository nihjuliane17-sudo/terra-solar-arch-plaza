import { createFileRoute } from "@tanstack/react-router";
import { SistemaPage } from "@/features/sistema";

export const Route = createFileRoute("/sistema")({ component: SistemaPage });
