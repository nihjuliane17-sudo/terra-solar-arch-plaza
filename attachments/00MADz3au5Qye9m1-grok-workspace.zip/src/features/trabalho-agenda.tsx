import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { STUDIO_MONTHS } from "@/lib/constants";
import { formatBR, monthGrid, todayISO, WEEKDAYS, weekKey } from "@/lib/dates";
import { forecastForTask, tasksOnDate } from "@/lib/derived";
import { brl } from "@/lib/money";
import { STAGE_DOT, stageShort } from "@/lib/stage-style";
import { useNara } from "@/lib/store";
import type { Client } from "@/lib/types";
import { cn, uid } from "@/lib/utils";

export function AgendaPanel() {
  const s = useNara();
  const [mi, setMi] = useState(() => {
    const m = new Date().getMonth();
    return STUDIO_MONTHS.some((x) => x.month === m) ? m : 9;
  });
  const [day, setDay] = useState(todayISO());
  const [week, setWeek] = useState(false);
  const year = 2026;
  const grid = monthGrid(year, mi);
  const [drag, setDrag] = useState<{ clientId: string; taskId: string; loose?: boolean } | null>(
    null,
  );

  const dropOn = (iso: string) => {
    if (!drag) return;
    if (drag.loose) s.patchLoose(drag.taskId, { date: iso });
    else s.setTaskDate(drag.clientId, drag.taskId, iso);
    setDrag(null);
  };

  const visible = week
    ? [
        grid.flat().filter((c) => {
          const w = weekKey(day);
          return weekKey(c.iso) === w;
        }),
      ]
    : grid;

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
      <div>
        <div className="mb-3 flex flex-wrap items-center gap-1">
          {STUDIO_MONTHS.map((m) => (
            <Button
              key={m.month}
              size="sm"
              variant={mi === m.month ? "default" : "ghost"}
              onClick={() => {
                setMi(m.month);
                setWeek(false);
              }}
            >
              {m.label}
            </Button>
          ))}
          <span className="flex-1" />
          <Button size="sm" variant={week ? "ghost" : "secondary"} onClick={() => setWeek(false)}>
            Mês
          </Button>
          <Button size="sm" variant={week ? "secondary" : "ghost"} onClick={() => setWeek(true)}>
            Semana
          </Button>
        </div>
        <div className="grid grid-cols-7 gap-1 text-center text-[11px] uppercase tracking-wider text-muted-foreground">
          {WEEKDAYS.map((d) => (
            <div key={d} className="py-1">
              {d}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {visible.flat().map((cell) => {
            const items = tasksOnDate(s, cell.iso);
            const hrs = items.reduce((a, x) => a + Number(x.task.hours || 0), 0);
            return (
              <button
                key={cell.iso}
                type="button"
                onClick={() => setDay(cell.iso)}
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => dropOn(cell.iso)}
                className={cn(
                  "min-h-24 rounded-md bg-card p-1.5 text-left shadow-card",
                  !cell.inMonth && !week && "opacity-40",
                  cell.iso === day && "ring-1 ring-primary",
                  cell.iso === todayISO() && "bg-secondary/60",
                )}
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span>{cell.date.getDate()}</span>
                  {hrs ? (
                    <span className="tabular-nums text-muted-foreground">{hrs}h</span>
                  ) : null}
                </div>
                <div className="mt-1 space-y-0.5">
                  {items.slice(0, 3).map((x) => (
                    <div
                      key={x.task.id}
                      draggable
                      onDragStart={() =>
                        setDrag({
                          clientId: "isLoose" in x.client ? "" : x.client.id,
                          taskId: x.task.id,
                          loose: "isLoose" in x.client,
                        })
                      }
                      className={cn(
                        "truncate rounded px-1 py-0.5 text-[10px]",
                        x.task.done && "line-through opacity-50",
                      )}
                    >
                      <span
                        className={cn(
                          "mr-1 inline-block size-1.5 rounded-full",
                          STAGE_DOT[x.task.type] || "bg-muted-foreground",
                        )}
                      />
                      {x.client.name}
                    </div>
                  ))}
                  {items.length > 3 ? (
                    <div className="text-[10px] text-muted-foreground">+{items.length - 3}</div>
                  ) : null}
                </div>
              </button>
            );
          })}
        </div>
      </div>
      <DayPanel iso={day} />
    </div>
  );
}

function DayPanel({ iso }: { iso: string }) {
  const s = useNara();
  const items = tasksOnDate(s, iso);
  const earn = items.reduce((a, x) => {
    if ("isLoose" in x.client) return a;
    return a + forecastForTask(x.client as Client, x.task);
  }, 0);
  const hrs = items.reduce((a, x) => a + Number(x.task.hours || 0), 0);
  const [cid, setCid] = useState(s.clients[0]?.id || "");
  const [stage, setStage] = useState("Esboços");
  const [hours, setHours] = useState("2");
  const [loose, setLoose] = useState("");
  const client = s.clients.find((c) => c.id === cid);

  return (
    <Card>
      <CardContent className="p-4">
        <h3 className="font-display text-xl">{formatBR(iso)}</h3>
        <p className="mb-4 text-xs text-muted-foreground">
          {hrs}h previstas · {brl(earn)} neste dia
        </p>
        <div className="mb-4 space-y-2">
          {items.map((x) => (
            <div key={x.task.id} className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                className="accent-primary"
                checked={!!x.task.done}
                onChange={() => {
                  if ("isLoose" in x.client) s.patchLoose(x.task.id, { done: !x.task.done });
                  else s.toggleTaskDone(x.client.id, x.task.id);
                }}
              />
              <span className={cn("flex-1", x.task.done && "line-through opacity-50")}>
                {x.client.name}
                <span className="text-muted-foreground"> · {stageShort(x.task.type)}</span>
              </span>
              <Badge variant="outline">{x.task.hours || 0}h</Badge>
              {"isLoose" in x.client ? (
                <button className="text-destructive" onClick={() => s.deleteLoose(x.task.id)}>
                  ×
                </button>
              ) : null}
            </div>
          ))}
        </div>
        <details className="mb-3 rounded-lg bg-secondary/50 p-3">
          <summary className="cursor-pointer text-sm">Marcar etapa</summary>
          <div className="mt-3 grid gap-2">
            <Select value={cid} onChange={(e) => setCid(e.target.value)}>
              {s.clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
            <Select value={stage} onChange={(e) => setStage(e.target.value)}>
              {(client?.tasks || []).map((t) => (
                <option key={t.id}>{t.type}</option>
              ))}
            </Select>
            <Input
              type="number"
              step="0.5"
              value={hours}
              onChange={(e) => setHours(e.target.value)}
            />
            <Button
              size="sm"
              onClick={() => {
                if (!client) return;
                const t = client.tasks.find((x) => x.type === stage);
                if (!t) return;
                s.patchTask(client.id, t.id, {
                  date: iso,
                  hours: parseFloat(hours) || t.hours,
                });
              }}
            >
              Marcar neste dia
            </Button>
          </div>
        </details>
        <details className="mb-4 rounded-lg bg-secondary/50 p-3">
          <summary className="cursor-pointer text-sm">Tarefa avulsa</summary>
          <div className="mt-3 grid gap-2">
            <Input
              placeholder="O que precisa ser feito"
              value={loose}
              onChange={(e) => setLoose(e.target.value)}
            />
            <Button
              size="sm"
              onClick={() => {
                if (!loose.trim()) return;
                s.addLoose({
                  id: uid(),
                  title: loose.trim(),
                  date: iso,
                  hours: 0,
                  done: false,
                });
                setLoose("");
              }}
            >
              Adicionar
            </Button>
          </div>
        </details>
        <Field label="Notas do dia">
          <Textarea
            className="paper-lines min-h-28"
            value={s.dayNotes[iso] || ""}
            onChange={(e) => s.setDayNote(iso, e.target.value)}
          />
        </Field>
        <Field label="Notas da semana" className="mt-3">
          <Textarea
            className="min-h-20"
            value={s.weekNotes[weekKey(iso)] || ""}
            onChange={(e) => s.setWeekNote(weekKey(iso), e.target.value)}
          />
        </Field>
      </CardContent>
    </Card>
  );
}
